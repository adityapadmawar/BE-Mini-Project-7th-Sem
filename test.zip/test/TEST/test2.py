#test case for login using pyunit

from selenium import webdriver
import time
import unittest
class loginTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome(executable_path="C:/Users/adity/PycharmProjects/test/drivers/chromedriver.exe")
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    def test_login_valid(self):
        self.driver.get("D:/BE/BE  Project/Mini Project/miniproject/mini website/login.html")
        self.driver.find_element_by_id("aditya").click()
        self.driver.find_element_by_id("uname").send_keys("aditya")
        self.driver.find_element_by_id("psw").send_keys("xyz")
        self.driver.find_element_by_id("button").click()
        time.sleep(2)

#    @classmethod
#    def tearDownClass(cls):
#        cls.driver.close()
#        cls.driver.quit()
#        print("Test completed")

if __name__ == '__main__':
    unittest.main()