#test case for "login" using selenium

from selenium import webdriver
import time

driver = webdriver.Chrome(executable_path="C:/Users/adity/PycharmProjects/test/drivers/chromedriver.exe")

driver.implicitly_wait(10)

driver.maximize_window()
driver.get("D:/BE/BE  Project/Mini Project/miniproject/mini website/index.html")
driver.find_element_by_id("aditya").click()


driver.get("D:/BE/BE  Project/Mini Project/miniproject/mini website/login.html")
driver.find_element_by_id("aditya").click()
driver.find_element_by_id("uname").send_keys("aditya")
driver.find_element_by_id("psw").send_keys("xyz")
driver.find_element_by_id("button").click()
time.sleep(2)
driver.close()
driver.quit()
print("Test completed")